package model;

import java.util.Map;

/**
 * A Car is a type of vehicle that travels on streets, traffic lights, and crosswalks.
 * <p>
 * Cars will not move onto a red light. They may move onto a green or yellow light. Cars
 * may also cross crosswalks only when the light is green.
 * </p>
 * <p>
 * Cars have a {@code deathTime} of 15 and will revive after being "poked" this many times.
 * </p>
 */

/**
 * @author tyler
 * @version 1.0
 */
public class Car extends AbstractVehicle
{
    /** The number of pokes required to revive a car.*/
    private static final int DEATH_TIME = 15;

    /**
     * Constructs a new Car at the specified coordinates and facing the given direction.
     *
     * @param theX   the initial x-coordinate of the Car
     * @param theY   the initial y-coordinate of the Car
     * @param theDir the initial direction the Car is facing
     */
    public Car(final int theX, final int theY, final Direction theDir)
    {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Determines if the Car can pass over a given terrain type under
     * the current light condition.
     *
     * @param theTerrain the type of terrain to check
     * @param theLight   the current traffic light condition
     * @return {@code true} if the Car can move onto the terrain,
     * {@code false} otherwise
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight)
    {
        if (theTerrain == Terrain.STREET)
        {
            return true;
        }
        if (theTerrain == Terrain.LIGHT && theLight != Light.RED)
        {
            return true;
        }
        if (theTerrain == Terrain.CROSSWALK && theLight == Light.GREEN)
        {
            return true;
        }
        return false;
    }

    /**
     * Chooses a direction for the Car to move based on neighboring terrain.
     * <p>
     * The Car prefers to continue straight, then turn left, then turn right, if possible.
     * Cars will only move onto a street, a non-red traffic light, or a green crosswalk.
     * If none of these options are available, the Car will reverse direction.
     * </p>
     *
     * @param theNeighbors a map of neighboring directions to terrain types
     * @return the chosen direction to move
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors)
    {
        final Direction straight = getDirection();
        final Direction left = straight.left();
        final Direction right = straight.right();
        final Direction reverse = straight.reverse();

        if (canPass(theNeighbors.get(straight), Light.GREEN)
                ||
                canPass(theNeighbors.get(straight), Light.YELLOW))
        {
            return straight;
        }

        if (canPass(theNeighbors.get(left), Light.GREEN)
                ||
                canPass(theNeighbors.get(left), Light.YELLOW))
        {
            return left;
        }

        if (canPass(theNeighbors.get(right), Light.GREEN)
                ||
                canPass(theNeighbors.get(right), Light.YELLOW))
        {
            return right;
        }
        return reverse;
    }
}
