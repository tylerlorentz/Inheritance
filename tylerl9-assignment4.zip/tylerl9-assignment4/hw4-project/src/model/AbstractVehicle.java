package model;

import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/**
 * This class implements the {@link Vehicle} interface and provides common
 * fields and methods shared by all concrete vehicle types.
 */

/**
 * @author tyler
 * @version 1.0
 */
public abstract class AbstractVehicle implements Vehicle
{

    /** The x-coordinate of the vehicle on the map. */
    private int myX;

    /** The y-coordinate of the vehicle on the map. */
    private int myY;

    /** The current direction the vehicle is facing. */
    private Direction myDir;

    /** The number of pokes required to revive the vehicle after death. */
    private final int myDeathTime;

    /** True if the vehicle is currently alive, false if dead. */
    private boolean myAlive;

    /** The number of pokes the vehicle has received while dead. */
    private int myPokes;

    /** The initial x-coordinate of the vehicle for resetting. */
    private final int myInitialX;

    /** The initial y-coordinate of the vehicle for resetting. */
    private final int myInitialY;

    /** The initial direction of the vehicle for resetting. */
    private final Direction myInitialDir;

    /**
     * Constructs a new AbstractVehicle with the specified position, and direction.
     */
    protected AbstractVehicle(final int theX, final int theY,
                              final Direction theDir, final int theDeathTime)
    {
        if (theX <= 0)
        {
            throw new IllegalArgumentException("X coordinate value cannot be 0 or negative, value was: " + theX);
        }
        else
        {
            myX = theX;
        }

        if (theY <= 0)
        {
            throw new IllegalArgumentException("Y coordinate value cannot be 0 or negative, value was: " + theY);
        }
        else
        {
            myY = theY;
        }

        if (theDir == null)
        {
            myDir = Objects.requireNonNull(theDir, "Direction cannot be null");
        }
        else
        {
            myDir = theDir;
        }

        if (theDeathTime < 0)
        {
            throw new IllegalArgumentException("Death time cannot be negative, value was: " + theDeathTime);
        }
        else
        {
            myDeathTime = theDeathTime;
        }

        myAlive = true;
        myPokes = 0;
        myInitialX = theX;
        myInitialY = theY;
        myInitialDir = theDir;
    }

    /**
     * Determines whether the vehicle can pass onto a given terrain under
     * a specific light condition. This method must be implemented by subclasses.
     *
     * @param theTerrain the terrain the vehicle is attempting to enter
     * @param theLight   the current light condition at the terrain
     * @return true if the vehicle can enter the terrain, false otherwise
     */
    @Override
    public abstract boolean canPass(Terrain theTerrain, Light theLight);

    /**
     * Chooses the next direction for the vehicle to move based on the
     * neighboring terrains. This method must be implemented by subclasses.
     *
     * @param theNeighbors a map of each direction to the corresponding terrain
     * @return the chosen direction to move
     */
    @Override
    public abstract Direction chooseDirection(Map<Direction, Terrain> theNeighbors);

    /**
     * Handles a collision with another vehicle. Updates the alive status
     * according to the death time rules.
     *
     * @param theOther the other vehicle involved in the collision
     */
    @Override
    public void collide(final Vehicle theOther)
    {
        if (myAlive && theOther.isAlive() && (this.getDeathTime() > theOther.getDeathTime()))
        {
                myAlive = false;
                myPokes = 0;
            }
        }

    /**
     * "Pokes" the vehicle. If the vehicle is dead, increments the poke count
     * and revives the vehicle if the poke count reaches the death time.
     * When revived, the vehicle's direction is randomized.
     */
    @Override
    public void poke()
    {
        if (!myAlive)
        {
            myPokes++;
            if (myPokes >= myDeathTime)
            {
                myAlive = true;
                myDir = Direction.random();
                myPokes = 0;
            }
        }
    }

    /**
     * Resets the vehicle to its initial position, direction, and alive status.
     */
    @Override
    public void reset()
    {
        myX = myInitialX;
        myY = myInitialY;
        myDir = myInitialDir;
        myAlive = true;
        myPokes = 0;
    }

    /**
     * Checks whether the vehicle is alive.
     *
     * @return true if the vehicle is alive, false if dead
     */
    @Override
    public boolean isAlive()
    {
        return myAlive;
    }

    /**
     * Returns the death time of the vehicle.
     *
     * @return the number of pokes required to revive the vehicle after death
     */
    @Override
    public int getDeathTime()
    {
        return myDeathTime;
    }

    /**
     * Returns the filename of the vehicle's image. If the vehicle is dead,
     * the filename will include "_dead".
     *
     * @return the image filename representing the vehicle
     */
    @Override
    public String getImageFileName()
    {
        String name = getClass().getSimpleName().toLowerCase(Locale.getDefault());
        if (!myAlive)
        {
            name += "_dead";
        }
        return name + ".gif";
    }

    /**
     * Returns the current direction the vehicle is facing.
     *
     * @return the current direction
     */
    @Override
    public Direction getDirection()
    {
        return myDir;
    }

    /**
     * Returns the current x-coordinate of the vehicle.
     *
     * @return the x-coordinate
     */
    @Override
    public int getX()
    {
        return myX;
    }

    /**
     * Returns the current y-coordinate of the vehicle.
     *
     * @return the y-coordinate
     */
    @Override
    public int getY()
    {
        return myY;
    }

    /**
     * Sets the direction of the vehicle.
     *
     * @param theDir the new direction
     */
    @Override
    public void setDirection(final Direction theDir)
    {
        myDir = theDir;
    }

    /**
     * Sets the x-coordinate of the vehicle.
     *
     * @param theX the new x-coordinate
     */
    @Override
    public void setX(final int theX)
    {
        myX = theX;
    }

    /**
     * Sets the y-coordinate of the vehicle.
     *
     * @param theY the new y-coordinate
     */
    @Override
    public void setY(final int theY)
    {
        myY = theY;
    }
}
