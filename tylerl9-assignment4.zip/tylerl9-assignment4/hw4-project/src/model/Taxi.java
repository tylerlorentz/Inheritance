package model;

/**
 * A Taxi is a type of Car that behaves exactly like a Car.
 * <p>
 * Taxis inherit all behavior from the Car class, including movement,
 * collision handling, and terrain traversal. Taxis have the same death time
 * as Cars.
 * </p>
 */

/**
 * @author tyler
 * @version 1.0
 */
public final class Taxi extends Car
{

    /**
     * Constructs a new Taxi at the specified position and direction.
     *
     * @param theX   the initial x-coordinate of the Taxi
     * @param theY   the initial y-coordinate of the Taxi
     * @param theDir the initial direction the Taxi is facing
     */
    public Taxi(final int theX, final int theY, final Direction theDir)
    {
        super(theX, theY, theDir);
    }
}
