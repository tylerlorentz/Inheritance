package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * An All-Terrain Vehicle (ATV) is a vehicle that can travel on any terrain
 * except walls.
 * <p>
 * ATVs move by choosing a direction randomly from the possible options:
 * left, straight, or right.
 * They have a {@code deathTime} of 25 and will revive automatically after
 * being "poked" this many times.
 * </p>
 */

/**
 * @author tyler
 * @version 1.0
 */
public final class Atv extends AbstractVehicle
{

    /** The number of pokes required to revive an Atv. */

    private static final int DEATH_TIME = 25;

    /**
     * Constructs an ATV at the given coordinates facing the given direction.
     *
     * @param theX   the initial x-coordinate of the ATV
     * @param theY   the initial y-coordinate of the ATV
     * @param theDir the initial direction the ATV is facing
     */
    public Atv(final int theX, final int theY, final Direction theDir)
    {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Determines if the ATV can pass a given terrain.
     *
     * @param theTerrain the terrain to check
     * @param theLight   the current light condition (ignored for ATVs)
     * @return {@code true} if the terrain is not a WALL, {@code false} otherwise
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight)
    {
        return theTerrain != Terrain.WALL;
    }

    /**
     * Chooses a direction for the ATV to move.
     * <p>
     * The ATV considers left, straight, and right directions
     * relative to its current direction.
     * From the valid directions, one is selected randomly.
     * </p>
     *
     * @param theNeighbors a map of neighboring directions to terrain types
     * @return the chosen direction to move
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors)
    {
        final List<Direction> options = new ArrayList<>();

        for (final Direction dir : List.of(getDirection().left(),
                getDirection(), getDirection().right()))
        {
            if (canPass(theNeighbors.get(dir), Light.GREEN))
            {
                options.add(dir);
            }
        }
        return options.get(new Random().nextInt(options.size()));
    }
}
