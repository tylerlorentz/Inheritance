package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * A Truck is a type of vehicle that travels only on streets, lights, and crosswalks.
 * <p>
 * Trucks randomly select to go straight, turn left, or turn right. If none of these
 * directions are legal, the truck will turn around. Trucks drive through all traffic
 * lights without stopping, but stop for red crosswalk lights. Trucks survive collisions
 * with any vehicle.
 * </p>
 */

/**
 * @author tyler
 * @version 1.0
 */
public final class Truck extends AbstractVehicle
{

    /** The number of pokes required to revive a truck. Always 0 for trucks. */
    private static final int DEATH_TIME = 0;

    /**
     * Constructs a new Truck at the specified position and direction.
     *
     * @param theX   the initial x-coordinate of the truck
     * @param theY   the initial y-coordinate of the truck
     * @param theDir the initial direction the truck is facing
     */
    public Truck(final int theX, final int theY, final Direction theDir)
    {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Determines if the truck can pass a given terrain with a given light condition.
     * <p>
     * Trucks can pass STREET, LIGHT, and CROSSWALK terrains.
     * Trucks stop for CROSSWALK only if the light is RED.
     * </p>
     *
     * @param theTerrain the terrain the truck is trying to enter
     * @param theLight   the current light condition
     * @return true if the truck can enter the terrain, false otherwise
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight)
    {
        if (theTerrain == Terrain.STREET || theTerrain == Terrain.LIGHT)
        {
            return true;
        }
        if (theTerrain == Terrain.CROSSWALK && theLight != Light.RED)
        {
            return true;
        }
        return false;
    }

    /**
     * Chooses the next direction for the truck to move based on neighboring terrains.
     * <p>
     * The truck will randomly select among valid directions (left, straight, right).
     * If none are valid, the truck reverses direction.
     * </p>
     *
     * @param theNeighbors a map of each direction to the corresponding terrain
     * @return the direction the truck chooses to move
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors)
    {
        final List<Direction> possibleDir = new ArrayList<>();

        for (final Direction dir : List.of(getDirection().left(),
                getDirection(), getDirection().right()))
        {
            final Terrain t = theNeighbors.get(dir);
            if (t == Terrain.STREET || t == Terrain.LIGHT || t == Terrain.CROSSWALK)
            {
                possibleDir.add(dir);
            }
        }
        if (!possibleDir.isEmpty())
        {
            return possibleDir.get(new Random().nextInt(possibleDir.size()));
        }
        return getDirection().reverse();
    }
}
