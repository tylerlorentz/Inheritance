package model;

import java.util.Map;

/**
 * A Bicycle is a type of vehicle that can travel on trails, streets, traffic lights,
 * and crosswalks.
 * <p>
 * Bicycles prefer to move on trails first, then streets, lights, or crosswalks if no trails
 * are available. If there is no valid forward, left, or right path, the Bicycle will reverse
 * direction.
 * </p>
 * <p>
 * Bicycles have a {@code deathTime} of 35 and will revive after being "poked" this many times.
 * </p>
 */

/**
 * @author tyler
 * @version 1.0
 */
public class Bicycle extends AbstractVehicle
{

    /** The number of pokes required to revive a bicycle.*/
    private static final int DEATH_TIME = 35;

    /**
     * Constructs a new Bicycle at the specified coordinates and facing the given direction.
     *
     * @param theX   the initial x-coordinate of the Bicycle
     * @param theY   the initial y-coordinate of the Bicycle
     * @param theDir the initial direction the Bicycle is facing
     */
    public Bicycle(final int theX, final int theY, final Direction theDir)
    {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Determines if the Bicycle can pass over a given terrain type with
     * the specified traffic light.
     * @param theTerrain the type of terrain to check
     * @param theLight   the current state of the traffic light
     * @return {@code true} if the Bicycle can move onto the terrain, {@code false} otherwise
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight)
    {
        return theTerrain == Terrain.TRAIL
                || theTerrain == Terrain.STREET
                || theTerrain == Terrain.LIGHT
                || theTerrain == Terrain.CROSSWALK;
    }

    /**
     * Chooses a direction for the Bicycle to move based on neighboring terrain.
     * <p>
     * The Bicycle prefers to continue straight if a trail is ahead, then left
     * or right if a trail is
     * available. If no trail is available, it will choose a valid street, light,
     * or crosswalk path
     * in the same order. As a last resort, the Bicycle will reverse direction.
     * </p>
     *
     * @param theNeighbors a map of neighboring directions to terrain types
     * @return the chosen direction to move
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors)
    {
        final Direction straight = getDirection();
        final Direction left = straight.left();
        final Direction right = straight.right();
        final Direction reverse = straight.reverse();

        if (theNeighbors.get(straight) == Terrain.TRAIL)
        {
            return straight;
        }
        if (theNeighbors.get(left) == Terrain.TRAIL)
        {
            return left;
        }
        if (theNeighbors.get(right) == Terrain.TRAIL)
        {
            return right;
        }
        if (canPass(theNeighbors.get(straight), Light.GREEN))
        {
            return straight;
        }
        if (canPass(theNeighbors.get(left), Light.GREEN))
        {
            return left;
        }
        if (canPass(theNeighbors.get(right), Light.GREEN))
        {
            return right;
        }
        return reverse;
    }
}
