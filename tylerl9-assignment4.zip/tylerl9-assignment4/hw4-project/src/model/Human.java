package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Humans stop at crosswalks with a green light but will cross at red or yellow.
 * They move randomly on grass, preferring left, straight, or right relative to their
 * current direction. If no valid movement is available, they reverse direction.
 */

/**
 * @author tyler
 * @version 1.0
 */

public final class Human extends AbstractVehicle
{
    /** The number of pokes required to revive a human.*/
    private static final int DEATH_TIME = 45;

    /**
     * Constructs a Human at the given coordinates facing the given direction.
     *
     * @param theX   the initial x-coordinate of the Human
     * @param theY   the initial y-coordinate of the Human
     * @param theDir the initial direction the Human is facing
     */
    public Human(final int theX, final int theY, final Direction theDir)
    {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Determines if the Human can pass a given terrain based on traffic lights.
     *
     * @param theTerrain the terrain to check
     * @param theLight   the current light condition
     * @return {@code true} if the terrain is grass or a crosswalk with a
     * non-green light, {@code false} otherwise
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight)
    {
        if (theTerrain == Terrain.CROSSWALK && theLight != Light.GREEN)
        {
            return true;
        }
        if (theTerrain == Terrain.GRASS)
        {
            return true;
        }
            return false;
        }

    /**
     * Chooses a direction for the Human to move.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors)
    {
        final Direction straight = getDirection();
        final Direction left = straight.left();
        final Direction right = straight.right();
        final Direction reverse = straight.reverse();

        if (theNeighbors.get(left) == Terrain.CROSSWALK)
        {
            return left;
        }
        if (theNeighbors.get(straight) == Terrain.CROSSWALK)
        {
            return straight;
        }
        if (theNeighbors.get(right) == Terrain.CROSSWALK)
        {
            return right;
        }

        final List<Direction> options = new ArrayList<>();
        if (theNeighbors.get(left) == Terrain.GRASS)
        {
            options.add(left);
        }
        if (theNeighbors.get(straight) == Terrain.GRASS)
        {
            options.add(straight);
        }
        if (theNeighbors.get(right) == Terrain.GRASS)
        {
            options.add(right);
        }
        if (!options.isEmpty())
        {
            return options.get(new Random().nextInt(options.size()));
        }
        return reverse;
    }
}
