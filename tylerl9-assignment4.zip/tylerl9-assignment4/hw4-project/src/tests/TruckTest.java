package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

import model.*;
import org.junit.jupiter.api.Test;

class TruckTest {

        @Test
        public void testTruckConstructor() {
            final Truck t = new Truck(10, 11, Direction.NORTH);

            assertEquals(10, t.getX(), "Truck x coordinate not initialized correctly!");
            assertEquals(11, t.getY(), "Truck y coordinate not initialized correctly!");
            assertEquals(Direction.NORTH, t.getDirection(), "Truck direction not initialized correctly!");
            assertEquals(0, t.getDeathTime(), "Truck death time not initialized correctly!");
            assertTrue(t.isAlive(), "Truck isAlive() fails initially!");
        }

        /** Test method for Truck setters. */
        @Test
        public void testTruckSetters() {
            final Truck t = new Truck(10, 11, Direction.NORTH);

            t.setX(12);
            assertEquals(12, t.getX(), "Truck setX failed!");
            t.setY(13);
            assertEquals(13, t.getY(), "Truck setY failed!");
            t.setDirection(Direction.SOUTH);
            assertEquals(Direction.SOUTH, t.getDirection(), "Truck setDirection failed!");
        }

    @Test
    public void testGetImageFileNameAlive() {
        final Truck t = new Truck(0, 0, Direction.NORTH);
        String expected = "truck.gif";
        assertEquals(expected, t.getImageFileName());
        t.collide(new Truck(1, 1, Direction.SOUTH));
        assertFalse(t.getImageFileName().contains("dead"));
    }

    @Test
    public void testPokeResurrection() {
        final Truck t = new Truck(0, 0, Direction.NORTH);
        t.collide(new Truck(1, 1, Direction.SOUTH));
        t.poke();
        assertTrue(t.isAlive(), "Truck should always remain alive since deathTime = 0");
    }

    @Test
    public void testCollide() {
        final Truck t1 = new Truck(0, 0, Direction.NORTH);
        final Truck t2 = new Truck(1, 1, Direction.SOUTH);

        t1.collide(t2);
        assertTrue(t1.isAlive());
        assertTrue(t2.isAlive());
    }

    @Test
    public void testReset() {
        final Truck t = new Truck(5, 6, Direction.EAST);
        t.setX(10);
        t.setY(20);
        t.setDirection(Direction.SOUTH);
        t.poke(); // maybe mark it dead
        t.reset();
        assertEquals(5, t.getX());
        assertEquals(6, t.getY());
        assertEquals(Direction.EAST, t.getDirection());
        assertTrue(t.isAlive());
    }


        /**
         * Test method for {@link Truck#canPass(Terrain, Light)}.
         */
        @Test
        public void testCanPass() {

            final List<Terrain> validTerrain = new ArrayList<>();
            validTerrain.add(Terrain.STREET);
            validTerrain.add(Terrain.CROSSWALK);
            validTerrain.add(Terrain.LIGHT);


            final Truck truck = new Truck(0, 0, Direction.NORTH);
            for (final Terrain destinationTerrain : Terrain.values()) {
                for (final Light currentLightCondition : Light.values()) {
                    if (destinationTerrain == Terrain.STREET) {

                        assertTrue(truck.canPass(destinationTerrain, currentLightCondition),
                                "Truck should be able to pass GRASS with light " + currentLightCondition);
                    } else if (destinationTerrain == Terrain.LIGHT) {

                            assertTrue(truck.canPass(destinationTerrain, currentLightCondition),
                                    "Truck should NOT be able to pass " + destinationTerrain
                                            + ", with light " + currentLightCondition);
                        }
                    else if (destinationTerrain == Terrain.CROSSWALK) {
                                if (currentLightCondition == Light.GREEN || currentLightCondition == Light.YELLOW) {
                                    assertTrue(truck.canPass(destinationTerrain, currentLightCondition),
                                            "Truck should NOT be able to pass " + destinationTerrain
                                                    + ", with light " + currentLightCondition);
                                } else {
                                    assertFalse(truck.canPass(destinationTerrain, currentLightCondition),
                                            "Truck should be able to pass " + destinationTerrain
                                                    + ", with light " + currentLightCondition);
                                }
                            }
                        }
                    }
                }

    @Test
    public void testCanPassNotValidTerrain() {
        final Truck truck = new Truck(0, 0, Direction.NORTH);
        final List<Terrain> validTerrain = List.of(Terrain.STREET, Terrain.CROSSWALK, Terrain.LIGHT);

        assertTrue(validTerrain.contains(Terrain.STREET));
        truck.canPass(Terrain.STREET, Light.RED);

        assertFalse(validTerrain.contains(Terrain.GRASS));
        truck.canPass(Terrain.GRASS, Light.RED);
    }

         /**
         * Test method for {@link Truck#chooseDirection(java.util.Map)}.
         */
        @Test
        public void testTruckChooseDirection() {
            final Truck truck = new Truck(0, 0, Direction.NORTH);

            final Map<Direction, Terrain> neighbors1 = new HashMap<>();
            neighbors1.put(Direction.NORTH, Terrain.STREET);
            neighbors1.put(Direction.WEST, Terrain.CROSSWALK);
            neighbors1.put(Direction.EAST, Terrain.LIGHT);
            neighbors1.put(Direction.SOUTH, Terrain.GRASS);

            final Direction choice = truck.chooseDirection(neighbors1);
            assertTrue(EnumSet.of(Direction.NORTH, Direction.WEST, Direction.EAST).contains(choice),
                    "Truck should choose NORTH, WEST, or EAST when valid terrains are available");

            final Map<Direction, Terrain> neighbors2 = new HashMap<>();
            for (Direction d : Direction.values()) {
                neighbors2.put(d, Terrain.GRASS);
            }
            assertEquals(Direction.SOUTH, truck.chooseDirection(neighbors2));
        }
}
